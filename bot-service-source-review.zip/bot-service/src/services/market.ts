import { logger } from '../utils/logger';
import { parseUnits } from 'viem';

// Trade signal interface for market analysis
export interface TradeSignal {
  direction: 'LONG' | 'SHORT';
  confidence: number;
  tokenAddress: string;
  tokenSymbol: string;
  suggestedAmount: bigint;
  minAmountOut: bigint;
  reason: string;
  takeProfitPercent: number;
  trailingStopPercent: number;
  profitLockPercent: number;
}
import { positionService } from './positions';
import { signalEngine, UnifiedSignal, Timeframe } from './signalEngine';

// Candle data structure
interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// Market analysis result
interface MarketAnalysis {
  direction: 'LONG' | 'SHORT';  // Always LONG or SHORT, never HOLD
  confidence: number;
  reason: string;
  indicators: string[];
  isReversalSignal: boolean;
  suggestedTP: number;
  suggestedSL: number;
  // Overheating & warnings
  isOverheated: boolean;
  isWeekendWarning: boolean;
  weekendAlertLevel: 'none' | 'yellow' | 'red';
  scalpingRecommended: boolean;
  marketWarning?: string;
  isWeak?: boolean; // Signal is too weak to trade
  strength?: number; // Signal strength 1-10 (NEW)
  metrics: {
    rsi: number;
    macd: string;
    priceChange1h: string;
    volumeRatio: string;
    conditionsMet: number;
    riskReward: string;
    trend: string;
    dayOfWeek: string;
    trendAlignment?: number;
    directionalTfCount?: number;
    h1Trend?: string;
  };
}

// Strategy modes
export type TradingStrategy = 'conservative' | 'normal' | 'risky' | 'aggressive';

// Strategy configs - LOWERED THRESHOLDS FOR MORE TRADES
const STRATEGY_CONFIGS = {
  conservative: {
    minConfidence: 60,
    minConditions: 3,
    patternOnly: false,
    profitLockPercent: 0.5
  },
  normal: {
    minConfidence: 40,
    minConditions: 2,
    patternOnly: false,
    profitLockPercent: 0.5
  },
  risky: {
    minConfidence: 25,  // LOWERED from 40% - triggers more trades!
    minConditions: 1,   // LOWERED from 2 - single condition OK
    patternOnly: false,
    profitLockPercent: 0.5
  },
  aggressive: {
    minConfidence: 25,
    minConditions: 1,
    patternOnly: false,
    profitLockPercent: 0.2
  }
};

/** Aggressive/risky: allow strong single-TF signal when unified MTF is HOLD or low. */
function applyAggressiveTfBoost(
  signal: UnifiedSignal,
  strategy: TradingStrategy
): { direction: 'LONG' | 'SHORT' | 'HOLD'; confidence: number } {
  if (strategy !== 'aggressive' && strategy !== 'risky') {
    return { direction: signal.direction, confidence: signal.confidence };
  }

  const directional = signal.timeframes
    .filter((tf) => tf.direction === 'LONG' || tf.direction === 'SHORT')
    .sort((a, b) => b.confidence - a.confidence);

  const best = directional[0];
  if (!best || best.confidence < 45) {
    return { direction: signal.direction, confidence: signal.confidence };
  }

  const boostedConf = Math.max(
    signal.confidence,
    Math.round(best.confidence * 0.9)
  );

  if (signal.direction === 'HOLD' || signal.confidence < STRATEGY_CONFIGS[strategy].minConfidence) {
    return {
      direction: best.direction as 'LONG' | 'SHORT',
      confidence: boostedConf,
    };
  }

  return { direction: signal.direction, confidence: boostedConf };
}

// Token config - ARBITRUM ONLY
const TOKEN_SYMBOLS: Record<number, Record<string, string>> = {
  // ARBITRUM - Active
  42161: {
    '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1': 'ETHUSDT',   // WETH
    '0x912CE59144191C1204E64559FE8253a0e49E6548': 'ARBUSDT',   // ARB
    '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f': 'BTCUSDT',   // WBTC
  }
};

// ============================================================================
// PERFORMANCE: Memory Cache for OHLCV Data (5 seconds TTL)
// ============================================================================
interface CacheEntry<T> {
  data: T;
  timestamp: number;
  source: string;
}

const ohlcvCache = new Map<string, CacheEntry<Candle[]>>();
const OHLCV_CACHE_TTL = 5000; // 5 seconds

// Indicator cache (30 seconds TTL)
const indicatorCache = new Map<string, CacheEntry<{ rsi: number; macd: any; trend: string }>>();
const INDICATOR_CACHE_TTL = 30000; // 30 seconds

function getCachedOHLCV(key: string): Candle[] | null {
  const cached = ohlcvCache.get(key);
  if (cached && Date.now() - cached.timestamp < OHLCV_CACHE_TTL) {
    logger.debug('OHLCV cache HIT', { key, source: cached.source });
    return cached.data;
  }
  return null;
}

function setCachedOHLCV(key: string, data: Candle[], source: string): void {
  ohlcvCache.set(key, { data, timestamp: Date.now(), source });
}

/**
 * Fetch with timeout and retry logic
 */
async function fetchWithRetry(url: string, retries: number = 3, timeoutMs: number = 10000): Promise<Response> {
  let lastError: Error | null = null;

  for (let i = 0; i < retries; i++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Monadier-Bot/1.0'
        }
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        return response;
      }

      // Rate limit - wait and retry
      if (response.status === 429) {
        const waitMs = Math.pow(2, i) * 1000; // Exponential backoff
        logger.warn(`Rate limited, waiting ${waitMs}ms before retry ${i + 1}/${retries}`);
        await new Promise(r => setTimeout(r, waitMs));
        continue;
      }

      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    } catch (err: any) {
      lastError = err;
      if (err.name === 'AbortError') {
        logger.warn(`Request timeout (attempt ${i + 1}/${retries})`, { url: url.slice(0, 50) });
      } else {
        logger.warn(`Fetch failed (attempt ${i + 1}/${retries})`, { error: err.message || String(err) });
      }

      // Wait before retry (exponential backoff)
      if (i < retries - 1) {
        await new Promise(r => setTimeout(r, Math.pow(2, i) * 500));
      }
    }
  }

  throw lastError || new Error('All retries failed');
}

/**
 * OPTIMIZED: Fetch candle data with parallel API calls and 5s cache
 * Uses Promise.race for fastest response, with 3s timeout per exchange
 */
async function fetchCandles(symbol: string, interval: string = '1h', limit: number = 30): Promise<Candle[]> {
  // Check cache first
  const cacheKey = `${symbol}_${interval}_${limit}`;
  const cached = getCachedOHLCV(cacheKey);
  if (cached) return cached;

  const TIMEOUT_MS = 3000; // 3 seconds per exchange

  // Helper to fetch with timeout
  const fetchWithTimeout = async (url: string, timeout: number): Promise<Response> => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: { 'Accept': 'application/json', 'User-Agent': 'Monadier-Bot/1.0' }
      });
      clearTimeout(timeoutId);
      return response;
    } catch (err) {
      clearTimeout(timeoutId);
      throw err;
    }
  };

  // Build all exchange fetch promises
  const exchangeFetchers: Array<{ name: string; fetch: () => Promise<Candle[]> }> = [
    {
      name: 'Binance',
      fetch: async () => {
        const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
        const response = await fetchWithTimeout(url, TIMEOUT_MS);
        const data = await response.json();
        if (!Array.isArray(data) || data.length === 0) throw new Error('No data');
        return data.map((c: any[]) => ({
          time: c[0], open: parseFloat(c[1]), high: parseFloat(c[2]),
          low: parseFloat(c[3]), close: parseFloat(c[4]), volume: parseFloat(c[5])
        }));
      }
    },
    {
      name: 'Bybit',
      fetch: async () => {
        const bybitInterval = interval === '1h' ? '60' : interval === '5m' ? '5' : interval === '15m' ? '15' : interval === '1m' ? '1' : interval === '4h' ? '240' : '60';
        const url = `https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol}&interval=${bybitInterval}&limit=${limit}`;
        const response = await fetchWithTimeout(url, TIMEOUT_MS);
        const data = await response.json();
        if (!data.result?.list?.length) throw new Error('No data');
        return data.result.list.reverse().map((c: any[]) => ({
          time: parseInt(c[0]), open: parseFloat(c[1]), high: parseFloat(c[2]),
          low: parseFloat(c[3]), close: parseFloat(c[4]), volume: parseFloat(c[5])
        }));
      }
    },
    {
      name: 'KuCoin',
      fetch: async () => {
        const kucoinSymbol = symbol.replace('USDT', '-USDT');
        const kucoinInterval = interval === '1h' ? '1hour' : interval === '5m' ? '5min' : interval === '15m' ? '15min' : interval === '1m' ? '1min' : interval === '4h' ? '4hour' : '1hour';
        const endAt = Math.floor(Date.now() / 1000);
        const intervalSecs = interval === '1h' ? 3600 : interval === '4h' ? 14400 : interval === '15m' ? 900 : interval === '5m' ? 300 : 60;
        const startAt = endAt - (limit * intervalSecs);
        const url = `https://api.kucoin.com/api/v1/market/candles?type=${kucoinInterval}&symbol=${kucoinSymbol}&startAt=${startAt}&endAt=${endAt}`;
        const response = await fetchWithTimeout(url, TIMEOUT_MS);
        const data = await response.json();
        if (!data.data?.length) throw new Error('No data');
        return data.data.reverse().map((c: any[]) => ({
          time: parseInt(c[0]) * 1000, open: parseFloat(c[1]), high: parseFloat(c[3]),
          low: parseFloat(c[4]), close: parseFloat(c[2]), volume: parseFloat(c[5])
        }));
      }
    },
    {
      name: 'OKX',
      fetch: async () => {
        const okxSymbol = symbol.replace('USDT', '-USDT');
        const okxInterval = interval === '1h' ? '1H' : interval === '4h' ? '4H' : interval;
        const url = `https://www.okx.com/api/v5/market/candles?instId=${okxSymbol}&bar=${okxInterval}&limit=${limit}`;
        const response = await fetchWithTimeout(url, TIMEOUT_MS);
        const data = await response.json();
        if (!data.data?.length) throw new Error('No data');
        return data.data.reverse().map((c: any[]) => ({
          time: parseInt(c[0]), open: parseFloat(c[1]), high: parseFloat(c[2]),
          low: parseFloat(c[3]), close: parseFloat(c[4]), volume: parseFloat(c[5])
        }));
      }
    }
  ];

  // PARALLEL: Race all exchanges - first success wins
  const fetchPromises = exchangeFetchers.map(async (ex) => {
    try {
      const candles = await ex.fetch();
      return { name: ex.name, candles, success: true };
    } catch (err: any) {
      logger.debug(`${ex.name} failed`, { symbol, error: err.message?.slice(0, 30) });
      return { name: ex.name, candles: [] as Candle[], success: false };
    }
  });

  // Wait for all to complete, pick first successful
  const results = await Promise.all(fetchPromises);
  const successful = results.find(r => r.success && r.candles.length > 0);

  if (successful) {
    logger.debug('Fetched candles', { symbol, interval, source: successful.name, count: successful.candles.length });
    setCachedOHLCV(cacheKey, successful.candles, successful.name);
    return successful.candles;
  }

  // All failed - log which exchanges failed
  const failedExchanges = results.filter(r => !r.success).map(r => r.name);
  logger.error('All exchange APIs failed', { symbol, interval, failedExchanges });
  return [];
}

/**
 * Calculate Simple Moving Average
 */
function calculateSMA(data: number[], period: number): number {
  if (data.length < period) return data[data.length - 1] || 0;
  const slice = data.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

/**
 * Calculate Exponential Moving Average
 */
function calculateEMA(data: number[], period: number): number {
  if (data.length < period) return calculateSMA(data, Math.min(data.length, period));

  const multiplier = 2 / (period + 1);
  let ema = calculateSMA(data.slice(0, period), period);

  for (let i = period; i < data.length; i++) {
    ema = (data[i] - ema) * multiplier + ema;
  }

  return ema;
}

/**
 * Calculate RSI
 */
function calculateRSI(closes: number[], period: number = 14): number {
  if (closes.length < period + 1) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = closes.length - period; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

/**
 * Calculate MACD
 */
function calculateMACD(closes: number[]): { macd: number; signal: number; histogram: number } {
  const ema12 = calculateEMA(closes, 12);
  const ema26 = calculateEMA(closes, 26);
  const macd = ema12 - ema26;

  // Calculate signal line (9-period EMA of MACD)
  const macdHistory: number[] = [];
  for (let i = 26; i <= closes.length; i++) {
    const slice = closes.slice(0, i);
    const e12 = calculateEMA(slice, 12);
    const e26 = calculateEMA(slice, 26);
    macdHistory.push(e12 - e26);
  }

  const signal = calculateEMA(macdHistory, 9);
  const histogram = macd - signal;

  return { macd, signal, histogram };
}

/**
 * Analyze market conditions - SAME LOGIC AS UI (6-Factor System)
 * This ensures bot trades in the same direction as UI shows
 */
export async function analyzeMarket(
  chainId: number,
  tokenAddress: string,
  strategy: TradingStrategy = 'normal'
): Promise<MarketAnalysis | null> {
  const strategyConfig = STRATEGY_CONFIGS[strategy];

  // Get trading symbol
  const symbol = TOKEN_SYMBOLS[chainId]?.[tokenAddress];
  if (!symbol) {
    logger.warn('Unknown token for market analysis', { chainId, tokenAddress });
    return null;
  }

  // Fetch candle data - 1h candles for stable analysis
  const candles = await fetchCandles(symbol, '1h', 30);
  if (candles.length < 20) {
    logger.warn('Insufficient candle data', { symbol, count: candles.length });
    return null;
  }

  // Extract price arrays
  const closes = candles.map(c => c.close);
  const highs = candles.map(c => c.high);
  const lows = candles.map(c => c.low);
  const volumes = candles.map(c => c.volume);

  // Calculate indicators
  const rsi = calculateRSI(closes);
  const { macd, signal, histogram } = calculateMACD(closes);
  const sma7 = calculateSMA(closes, 7);
  const sma20 = calculateSMA(closes, 20);
  const sma50 = calculateSMA(closes, 50);

  // Volume analysis
  const avgVolume = calculateSMA(volumes, 20);
  const currentVolume = volumes[volumes.length - 1];
  const volumeRatio = avgVolume > 0 ? currentVolume / avgVolume : 1;
  const isHighVolume = volumeRatio > 1.5;

  // Price changes
  const currentPrice = closes[closes.length - 1];
  const price1hAgo = closes[closes.length - 2] || currentPrice;
  const price24hAgo = closes[0] || currentPrice;
  const priceChange1h = ((currentPrice - price1hAgo) / price1hAgo) * 100;
  const priceChange24h = ((currentPrice - price24hAgo) / price24hAgo) * 100;

  // RSI momentum
  const rsi5Ago = calculateRSI(closes.slice(0, -5));
  const rsiRising = rsi > rsi5Ago;
  const rsiFalling = rsi < rsi5Ago;

  // MACD crossover detection
  const prevHistogram = closes.length > 1 ? (() => {
    const prevCloses = closes.slice(0, -1);
    const { histogram: h } = calculateMACD(prevCloses);
    return h;
  })() : 0;
  const macdCrossover = histogram > 0 && prevHistogram <= 0;
  const macdCrossunder = histogram < 0 && prevHistogram >= 0;

  // Support/Resistance
  const recentCandles = candles.slice(-20);
  const recentHigh = Math.max(...recentCandles.map(c => c.high));
  const recentLow = Math.min(...recentCandles.map(c => c.low));
  const range = recentHigh - recentLow;
  const nearResistance = range > 0 && (recentHigh - currentPrice) / range < 0.1;
  const nearSupport = range > 0 && (currentPrice - recentLow) / range < 0.1;

  // Candle patterns
  const lastCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2];
  const lastCandleBody = Math.abs(lastCandle.close - lastCandle.open);
  const lastCandleRange = lastCandle.high - lastCandle.low;
  const lastCandleIsBearish = lastCandle.close < lastCandle.open;
  const lastCandleIsBullish = lastCandle.close > lastCandle.open;

  // Engulfing patterns
  const isBullishEngulfing = lastCandleIsBullish &&
    prevCandle && prevCandle.close < prevCandle.open &&
    lastCandle.close > prevCandle.open &&
    lastCandle.open < prevCandle.close;
  const isBearishEngulfing = lastCandleIsBearish &&
    prevCandle && prevCandle.close > prevCandle.open &&
    lastCandle.close < prevCandle.open &&
    lastCandle.open > prevCandle.close;

  // Wick patterns
  const upperWick = lastCandle.high - Math.max(lastCandle.open, lastCandle.close);
  const lowerWick = Math.min(lastCandle.open, lastCandle.close) - lastCandle.low;
  const hasLongUpperWick = upperWick > lastCandleBody * 2 && upperWick > lastCandleRange * 0.3;
  const hasLongLowerWick = lowerWick > lastCandleBody * 2 && lowerWick > lastCandleRange * 0.3;

  // === IMMEDIATE CANDLE MOMENTUM ===
  const recentBodies = recentCandles.slice(-10).map(c => Math.abs(c.close - c.open));
  const avgBodySize = recentBodies.reduce((a, b) => a + b, 0) / recentBodies.length;
  const isLargeCandle = lastCandleBody > avgBodySize * 1.5;
  const isVeryLargeCandle = lastCandleBody > avgBodySize * 2.5;

  // Check last 3 candles for consistent momentum
  const last3Candles = recentCandles.slice(-3);
  const bearishCandlesCount = last3Candles.filter(c => c.close < c.open).length;
  const bullishCandlesCount = last3Candles.filter(c => c.close > c.open).length;

  // Short-term momentum
  const shortTermMomentum = ((closes[closes.length - 1] - closes[closes.length - 3]) / closes[closes.length - 3]) * 100;
  const isStrongShortTermBearish = shortTermMomentum < -0.5 && bearishCandlesCount >= 2;
  const isStrongShortTermBullish = shortTermMomentum > 0.5 && bullishCandlesCount >= 2;

  // === REVERSAL PATTERN DETECTION ===
  // After a big red candle (crash), check if next candles are green (reversal)
  const candle3Ago = candles[candles.length - 4]; // The crash candle
  const candle2Ago = candles[candles.length - 3]; // First recovery candle
  const candle1Ago = candles[candles.length - 2]; // Second recovery candle (prevCandle)

  // Check for crash reversal pattern
  let isReversalPattern = false;
  let reversalStrength = 0;

  if (candle3Ago && candle2Ago && candle1Ago) {
    const crashCandleBody = Math.abs(candle3Ago.close - candle3Ago.open);
    const crashCandleIsBearish = candle3Ago.close < candle3Ago.open;
    const crashCandleDropPercent = ((candle3Ago.open - candle3Ago.close) / candle3Ago.open) * 100;

    // Crash candle criteria: big red candle with significant drop
    const isCrashCandle = crashCandleIsBearish &&
      crashCandleBody > avgBodySize * 2 && // At least 2x average body
      crashCandleDropPercent > 1.0; // At least 1% drop

    // Recovery candles: both green
    const firstRecoveryIsGreen = candle2Ago.close > candle2Ago.open;
    const secondRecoveryIsGreen = candle1Ago.close > candle1Ago.open;

    // Volume confirmation: recovery candles should have decent volume
    const avgVol3 = (candle3Ago.volume + candle2Ago.volume + candle1Ago.volume) / 3;
    const recoveryVolumeOk = candle2Ago.volume > avgVol3 * 0.7 || candle1Ago.volume > avgVol3 * 0.7;

    // Full reversal pattern: crash + 2 green candles + volume
    isReversalPattern = isCrashCandle &&
      firstRecoveryIsGreen &&
      secondRecoveryIsGreen &&
      recoveryVolumeOk;

    if (isReversalPattern) {
      // Calculate reversal strength based on recovery
      const recoveryPercent = ((candle1Ago.close - candle3Ago.close) / candle3Ago.close) * 100;
      reversalStrength = Math.min(recoveryPercent / crashCandleDropPercent, 1) * 100; // 0-100%

      logger.info('🔄 REVERSAL PATTERN DETECTED', {
        symbol,
        crashDrop: crashCandleDropPercent.toFixed(2) + '%',
        recoveryPercent: recoveryPercent.toFixed(2) + '%',
        reversalStrength: reversalStrength.toFixed(0) + '%',
        volumeConfirmed: recoveryVolumeOk
      });
    }
  }

  // Immediate momentum flags
  const immediateBearishMomentum = (isLargeCandle && lastCandleIsBearish) ||
    (isVeryLargeCandle && lastCandleIsBearish) ||
    (isStrongShortTermBearish && bearishCandlesCount === 3);
  const immediateBullishMomentum = (isLargeCandle && lastCandleIsBullish) ||
    (isVeryLargeCandle && lastCandleIsBullish) ||
    (isStrongShortTermBullish && bullishCandlesCount === 3);

  // === TREND ANALYSIS ===
  const last10Highs = highs.slice(-10);
  const last10Lows = lows.slice(-10);

  let higherLowsCount = 0;
  for (let i = 1; i < last10Lows.length; i++) {
    if (last10Lows[i] > last10Lows[i - 1]) higherLowsCount++;
  }
  const isFormingHigherLows = higherLowsCount >= 6;

  let lowerHighsCount = 0;
  for (let i = 1; i < last10Highs.length; i++) {
    if (last10Highs[i] < last10Highs[i - 1]) lowerHighsCount++;
  }
  const isFormingLowerHighs = lowerHighsCount >= 6;

  const isStrongUptrend = isFormingHigherLows && sma7 > sma20 && sma20 > sma50;
  const isStrongDowntrend = isFormingLowerHighs && sma7 < sma20 && sma20 < sma50;
  const trend = isStrongUptrend ? 'STRONG_UPTREND' : isStrongDowntrend ? 'STRONG_DOWNTREND' : 'NEUTRAL';

  // === 6-FACTOR CONFIRMATION SYSTEM (SAME AS UI) ===
  // Pattern detection is SUPER important - these arrows work great!

  // Hammer pattern (bullish reversal)
  const isHammer = hasLongLowerWick &&
    upperWick < lastCandleBody * 0.5 &&
    lowerWick > lastCandleBody * 2;

  // Shooting star (bearish reversal)
  const isShootingStar = hasLongUpperWick &&
    lowerWick < lastCandleBody * 0.5 &&
    upperWick > lastCandleBody * 2;

  // Strong pattern detection (these are the chart arrows that work great!)
  const hasBullishPattern = isBullishEngulfing || isHammer || (hasLongLowerWick && lastCandleIsBullish);
  const hasBearishPattern = isBearishEngulfing || isShootingStar || (hasLongUpperWick && lastCandleIsBearish);

  // SHORT CONDITIONS (6 factors) - Patterns get extra weight!
  const shortConditions = {
    rsiOverbought: rsi > 70 || (rsi > 60 && rsiFalling),
    macdBearish: macd < -0.5 || (macdCrossunder && Math.abs(macd) > 0.2),
    volumeConfirmed: isHighVolume && priceChange1h < 0,
    priceRejectedResistance: nearResistance && (isBearishEngulfing || hasLongUpperWick),
    lowerHighsForming: isFormingLowerHighs,
    immediateBearish: immediateBearishMomentum,
    // BONUS: Strong pattern detection (chart arrows!)
    strongBearishPattern: hasBearishPattern
  };
  const shortConditionsMet = Object.values(shortConditions).filter(Boolean).length;

  // LONG CONDITIONS (6 factors) - Patterns get extra weight!
  const longConditions = {
    rsiOversold: rsi < 30 || (rsi < 40 && rsiRising),
    macdBullish: macd > 0.5 || (macdCrossover && Math.abs(macd) > 0.2),
    volumeConfirmed: isHighVolume && priceChange1h > 0,
    priceBouncingSupport: nearSupport && (isBullishEngulfing || hasLongLowerWick),
    higherLowsForming: isFormingHigherLows,
    immediateBullish: immediateBullishMomentum,
    // BONUS: Strong pattern detection (chart arrows!)
    strongBullishPattern: hasBullishPattern,
    // REVERSAL: Crash followed by 2 green candles
    reversalPattern: isReversalPattern
  };
  const longConditionsMet = Object.values(longConditions).filter(Boolean).length;

  // Log conditions for debugging
  logger.debug('6-Factor Analysis', {
    symbol,
    rsi: rsi.toFixed(1),
    macd: macd.toFixed(4),
    volumeRatio: volumeRatio.toFixed(2),
    longConditions,
    shortConditions,
    longConditionsMet,
    shortConditionsMet
  });

  // === CONFIDENCE SCORING (now 7 factors with pattern bonus) ===
  const calculateConfidence = (conditionsMet: number, isPatternOnly: boolean): number => {
    // For aggressive/pattern-only mode, patterns are the main signal
    if (isPatternOnly) {
      return conditionsMet >= 1 ? 80 : 30; // High confidence if pattern exists
    }
    if (conditionsMet >= 6) return 95; // 6+ factors = very high confidence
    if (conditionsMet >= 5) return 90;
    if (conditionsMet >= 4) return 80;
    if (conditionsMet === 3) return 65;
    if (conditionsMet === 2) return 45;
    return 25;
  };

  // === AGGRESSIVE MODE: PATTERN-ONLY TRADING ===
  // If patternOnly is true, we ONLY look at candlestick patterns (the chart arrows!)
  if (strategyConfig.patternOnly) {
    if (hasBullishPattern) {
      const patternName = isBullishEngulfing ? 'Bullish Engulfing' : isHammer ? 'Hammer' : 'Long Lower Wick';
      logger.info(`🔥 AGGRESSIVE: ${patternName} detected - LONG signal!`, {
        symbol,
        pattern: patternName,
        profitLock: strategyConfig.profitLockPercent + '%'
      });
      return {
        direction: 'LONG',
        confidence: 80,
        reason: patternName,
        indicators: [patternName],
        isReversalSignal: true,
        suggestedTP: 3.0,
        suggestedSL: 0.5,
        isOverheated: rsi > 75 || rsi < 25,
        isWeekendWarning: false,
        weekendAlertLevel: 'none' as const,
        scalpingRecommended: false,
        metrics: {
          rsi: Math.round(rsi),
          macd: macd.toFixed(4),
          priceChange1h: priceChange1h.toFixed(2),
          volumeRatio: volumeRatio.toFixed(1),
          conditionsMet: 1,
          riskReward: '2.0',
          trend,
          dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' })
        }
      };
    }
    if (hasBearishPattern) {
      const patternName = isBearishEngulfing ? 'Bearish Engulfing' : isShootingStar ? 'Shooting Star' : 'Long Upper Wick';
      logger.info(`🔥 AGGRESSIVE: ${patternName} detected - SHORT signal!`, {
        symbol,
        pattern: patternName,
        profitLock: strategyConfig.profitLockPercent + '%'
      });
      return {
        direction: 'SHORT',
        confidence: 80,
        reason: patternName,
        indicators: [patternName],
        isReversalSignal: true,
        suggestedTP: 3.0,
        suggestedSL: 0.5,
        isOverheated: rsi > 75 || rsi < 25,
        isWeekendWarning: false,
        weekendAlertLevel: 'none' as const,
        scalpingRecommended: false,
        metrics: {
          rsi: Math.round(rsi),
          macd: macd.toFixed(4),
          priceChange1h: priceChange1h.toFixed(2),
          volumeRatio: volumeRatio.toFixed(1),
          conditionsMet: 1,
          riskReward: '2.0',
          trend,
          dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' })
        }
      };
    }
    // No pattern detected in aggressive mode - no trade
    logger.debug('AGGRESSIVE: No pattern detected, waiting...');
    return null;
  }

  // === DIRECTION DETERMINATION - SYNCED WITH UI ===
  // Requires 2 conditions minimum for reliable signals!
  let direction: 'LONG' | 'SHORT' | 'HOLD' = 'HOLD';
  let conditionsMet = 0;
  let conditions: Record<string, boolean> = {};

  // CONSERVATIVE: Need at least 2 conditions (same as UI!)
  if (longConditionsMet > shortConditionsMet && longConditionsMet >= 2) {
    direction = 'LONG';
    conditionsMet = longConditionsMet;
    conditions = longConditions;
  } else if (shortConditionsMet > longConditionsMet && shortConditionsMet >= 2) {
    direction = 'SHORT';
    conditionsMet = shortConditionsMet;
    conditions = shortConditions;
  } else if (longConditionsMet === shortConditionsMet && longConditionsMet >= 2) {
    // Tie-breaker: use recent momentum
    const momentum3 = ((closes[closes.length - 1] - closes[closes.length - 3]) / closes[closes.length - 3]) * 100;
    direction = momentum3 > 0 ? 'LONG' : 'SHORT';
    conditionsMet = longConditionsMet;
    conditions = momentum3 > 0 ? longConditions : shortConditions;
  }
  // If less than 2 conditions: direction stays HOLD (no trade)

  // === MOMENTUM OVERRIDE - REDUCED PENALTIES FOR MORE TRADES ===
  let momentumOverride = false;
  let confidencePenalty = 0;

  if (direction === 'LONG' && isVeryLargeCandle && lastCandleIsBearish) {
    if (shortConditionsMet >= 2) {
      direction = 'SHORT';
      conditionsMet = shortConditionsMet;
      conditions = shortConditions;
      momentumOverride = true;
      logger.info('⚠️ Momentum override: Large red candle switched LONG to SHORT');
    } else {
      // REDUCED: Don't go HOLD, just apply small penalty
      confidencePenalty = 10;
    }
  } else if (direction === 'SHORT' && isVeryLargeCandle && lastCandleIsBullish) {
    if (longConditionsMet >= 2) {
      direction = 'LONG';
      conditionsMet = longConditionsMet;
      conditions = longConditions;
      momentumOverride = true;
      logger.info('⚠️ Momentum override: Large green candle switched SHORT to LONG');
    } else {
      // REDUCED: Don't go HOLD, just apply small penalty
      confidencePenalty = 10;
    }
  } else if (direction === 'LONG' && isLargeCandle && lastCandleIsBearish) {
    confidencePenalty = 5;  // REDUCED from 15
  } else if (direction === 'SHORT' && isLargeCandle && lastCandleIsBullish) {
    confidencePenalty = 5;  // REDUCED from 15
  }

  // Calculate confidence with penalty
  const rawConfidence = calculateConfidence(conditionsMet, false);
  const confidence = Math.max(20, rawConfidence - confidencePenalty);

  // If HOLD, force to stronger signal (same as UI)
  let finalDirection: 'LONG' | 'SHORT' = direction as any;
  if (direction === 'HOLD') {
    finalDirection = longConditionsMet >= shortConditionsMet ? 'LONG' : 'SHORT';
    conditionsMet = Math.max(longConditionsMet, shortConditionsMet);
    logger.info(`Weak setup - forcing ${finalDirection} (${conditionsMet}/6 conditions)`);
  }

  // Check minimum conditions for strategy
  // With minConditions=0, this will almost never trigger!
  const isTooWeak = strategyConfig.minConditions > 0 &&
    (conditionsMet < strategyConfig.minConditions || confidence < strategyConfig.minConfidence);

  if (isTooWeak) {
    const weakReason = conditionsMet < strategyConfig.minConditions
      ? `Signal weak: ${conditionsMet}/${strategyConfig.minConditions} conditions`
      : `Confidence: ${confidence}% < ${strategyConfig.minConfidence}%`;
    logger.info(`${weakReason} for ${strategy} mode`);

    // Return analysis anyway for UI display (marked as weak)
    return {
      direction: finalDirection,
      confidence: Math.round(confidence),
      reason: `Waiting - ${weakReason}`,
      indicators: [],
      isReversalSignal: false,
      suggestedTP: 5,
      suggestedSL: 1,
      isOverheated: rsi > 75 || rsi < 25,
      isWeekendWarning: false,
      weekendAlertLevel: 'none' as const,
      scalpingRecommended: false,
      isWeak: true, // Flag to indicate signal is too weak
      metrics: {
        rsi: Math.round(rsi),
        macd: macd.toFixed(4),
        priceChange1h: priceChange1h.toFixed(2),
        volumeRatio: volumeRatio.toFixed(1),
        conditionsMet,
        riskReward: '0',
        trend,
        dayOfWeek: new Date().toLocaleDateString('en-US', { weekday: 'long' })
      }
    };
  }

  // === BUILD INDICATORS LIST ===
  const indicators: string[] = [];

  if (finalDirection === 'LONG') {
    // Reversal pattern first - strongest signal!
    if ((conditions as any).reversalPattern) indicators.push('Reversal Pattern 🔄');
    // Pattern next - these are the chart arrows that work great!
    if (conditions.strongBullishPattern) {
      if (isBullishEngulfing) indicators.push('Bullish Engulfing');
      else if (isHammer) indicators.push('Hammer');
      else indicators.push('Long Lower Wick');
    }
    if (conditions.rsiOversold) indicators.push(`RSI ${rsi.toFixed(0)}${rsiRising ? ' ↗' : ''}`);
    if (conditions.macdBullish) indicators.push(macdCrossover ? 'MACD Cross ↑' : 'MACD Bullish');
    if (conditions.volumeConfirmed) indicators.push(`Vol ${volumeRatio.toFixed(1)}x ↑`);
    if (conditions.priceBouncingSupport) indicators.push('Support Bounce');
    if (conditions.higherLowsForming) indicators.push('Higher Lows');
    if (conditions.immediateBullish) indicators.push('Strong Green Candle');
  } else {
    // Pattern first - these are the chart arrows that work great!
    if (conditions.strongBearishPattern) {
      if (isBearishEngulfing) indicators.push('Bearish Engulfing');
      else if (isShootingStar) indicators.push('Shooting Star');
      else indicators.push('Long Upper Wick');
    }
    if (conditions.rsiOverbought) indicators.push(`RSI ${rsi.toFixed(0)}${rsiFalling ? ' ↘' : ''}`);
    if (conditions.macdBearish) indicators.push(macdCrossunder ? 'MACD Cross ↓' : 'MACD Bearish');
    if (conditions.volumeConfirmed) indicators.push(`Vol ${volumeRatio.toFixed(1)}x ↓`);
    if (conditions.priceRejectedResistance) indicators.push('Resistance Rejection');
    if (conditions.lowerHighsForming) indicators.push('Lower Highs');
    if (conditions.immediateBearish) indicators.push('Strong Red Candle');
  }

  // Build reason
  const reason = indicators.slice(0, 3).join(' + ') || `${conditionsMet}/6 factors`;

  // === DYNAMIC TP/SL ===
  const now = new Date();
  const dayOfWeek = now.getDay();
  const hour = now.getUTCHours();
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const isSunday = dayOfWeek === 0;
  const isMonday = dayOfWeek === 1;
  const isSaturday = dayOfWeek === 6;
  const isWeekend = isSunday || isSaturday;

  // === OVERHEATING DETECTION ===
  // Market is overheated when RSI is extreme and price moved significantly
  const isOverbought = rsi > 75;
  const isOversold = rsi < 25;
  const isExtremeRSI = rsi > 80 || rsi < 20;
  const rapidPriceMove = Math.abs(priceChange1h) > 2.0; // 2%+ move in 1h
  const isOverheated = isExtremeRSI || (rapidPriceMove && (isOverbought || isOversold));

  // Detect potential reversal when overheated
  const potentialReversal = isOverheated && (
    (isOverbought && (hasBearishPattern || lastCandleIsBearish)) ||
    (isOversold && (hasBullishPattern || lastCandleIsBullish))
  );

  // Recommend scalping when overheated with reversal signals
  const scalpingRecommended = potentialReversal || (isExtremeRSI && isHighVolume);

  // === WEEKEND/MONDAY WARNING SYSTEM ===
  // Sunday evening to Monday = highest risk (institutional moves)
  // Saturday after peak hours = elevated risk
  let weekendAlertLevel: 'none' | 'yellow' | 'red' = 'none';
  let marketWarning: string | undefined;

  if (isSunday && hour >= 18) {
    // Sunday evening UTC - RED ALERT (market opens soon)
    weekendAlertLevel = 'red';
    marketWarning = 'RED ALERT: Sunday evening - high volatility expected as markets prepare to open';
  } else if (isMonday && hour < 12) {
    // Monday morning UTC - RED ALERT (institutional selling/buying)
    weekendAlertLevel = 'red';
    marketWarning = 'RED ALERT: Monday morning - institutional activity, expect sharp moves';
  } else if (isMonday) {
    // Monday afternoon - elevated risk
    weekendAlertLevel = 'yellow';
    marketWarning = 'Caution: Monday market instability - reduced position sizes recommended';
  } else if (isSunday) {
    // Sunday - yellow warning
    weekendAlertLevel = 'yellow';
    marketWarning = 'Weekend trading: Lower liquidity, wider spreads possible';
  } else if (isSaturday && hour >= 12) {
    // Saturday afternoon/evening - watch for weekend dumps
    weekendAlertLevel = 'yellow';
    marketWarning = 'Weekend alert: Watch for late Saturday dumps before Sunday instability';
  }

  const isWeekendWarning = weekendAlertLevel !== 'none';

  // Log overheating and warnings
  if (isOverheated) {
    logger.warn('🔥 MARKET OVERHEATED', {
      symbol,
      rsi: rsi.toFixed(1),
      priceChange1h: priceChange1h.toFixed(2) + '%',
      potentialReversal,
      scalpingRecommended
    });
  }

  if (isWeekendWarning) {
    logger.warn(`⚠️ ${weekendAlertLevel.toUpperCase()} ALERT: ${marketWarning}`);
  }

  let baseTP = 7.5;
  let baseSL = 1.0;

  if (isMonday) {
    baseTP = 4.0; // Even tighter on Monday
    baseSL = 0.6;
  } else if (isSunday) {
    baseTP = 3.5; // Very tight on Sunday
    baseSL = 0.5;
  } else if (isSaturday) {
    baseTP = 5.0;
    baseSL = 0.8;
  }

  // If overheated, use scalping parameters
  if (scalpingRecommended) {
    baseTP = 2.0; // Quick scalp TP
    baseSL = 0.5; // Tight stop
    logger.info('🎯 Scalping mode activated due to overheated market');
  }

  if (isStrongUptrend && finalDirection === 'LONG') {
    baseTP = Math.min(baseTP + 2, 10);
  } else if (isStrongDowntrend && finalDirection === 'SHORT') {
    baseTP = Math.min(baseTP + 2, 10);
  }

  if (volumeRatio > 2.0) {
    baseSL = Math.min(baseSL + 0.5, 2.0);
    baseTP = Math.min(baseTP + 1, 10);
  }

  if (confidence >= 85) {
    baseTP = Math.min(baseTP + 1, 10);
  } else if (confidence < 60) {
    baseTP = Math.max(baseTP - 1, 5);
  }

  const suggestedTP = Math.round(baseTP * 10) / 10;
  const suggestedSL = Math.round(baseSL * 10) / 10;

  // Risk/Reward
  const distanceToResistance = ((recentHigh - currentPrice) / currentPrice) * 100;
  const distanceToSupport = ((currentPrice - recentLow) / currentPrice) * 100;
  const takeProfitDistance = Math.max(finalDirection === 'LONG' ? distanceToResistance : distanceToSupport, 0.3);
  const stopLossDistance = Math.max(finalDirection === 'LONG' ? distanceToSupport : distanceToResistance, 0.3);
  const riskReward = Math.min(Math.max(takeProfitDistance / stopLossDistance, 0.1), 10);

  logger.info(`📊 ${finalDirection} signal generated`, {
    symbol,
    strategy,
    conditionsMet: `${conditionsMet}/6`,
    confidence: confidence + '%',
    indicators: indicators.slice(0, 3),
    trend,
    suggestedTP: suggestedTP + '%',
    suggestedSL: suggestedSL + '%'
  });

  return {
    direction: finalDirection,
    confidence: Math.round(confidence),
    reason,
    indicators,
    isReversalSignal: nearSupport || nearResistance || potentialReversal,
    suggestedTP,
    suggestedSL,
    isOverheated,
    isWeekendWarning,
    weekendAlertLevel,
    scalpingRecommended,
    marketWarning,
    metrics: {
      rsi: Math.round(rsi),
      macd: macd.toFixed(4),
      priceChange1h: priceChange1h.toFixed(2),
      volumeRatio: volumeRatio.toFixed(1),
      conditionsMet,
      riskReward: riskReward.toFixed(2),
      trend,
      dayOfWeek: dayNames[dayOfWeek]
    }
  };
}

/**
 * Generate trade signal for bot execution
 */
export async function generateTradeSignal(
  chainId: number,
  tokenAddress: string,
  userBalance: bigint,
  riskLevelBps: number = 500,
  strategy: TradingStrategy = 'normal'
): Promise<TradeSignal | null> {
  const strategyConfig = STRATEGY_CONFIGS[strategy];
  const analysis = await analyzeMarket(chainId, tokenAddress, strategy);

  // Get token symbol
  const symbol = TOKEN_SYMBOLS[chainId]?.[tokenAddress] || 'UNKNOWN';
  const tokenSymbol = symbol.replace('USDT', '');

  // Save analysis to Supabase for UI display (even if no trade)
  if (analysis) {
    await positionService.saveAnalysis({
      chainId,
      tokenAddress,
      tokenSymbol,
      signal: analysis.direction,
      confidence: analysis.confidence,
      currentPrice: parseFloat(analysis.metrics.macd) || 0,
      factors: {
        rsi: analysis.metrics.rsi,
        macdSignal: analysis.metrics.macd,
        volumeSpike: parseFloat(analysis.metrics.volumeRatio) > 1.5,
        trend: analysis.metrics.trend,
        pattern: analysis.indicators[0] || null,
        priceChange24h: parseFloat(analysis.metrics.priceChange1h) || 0
      },
      recommendation: `${analysis.direction} - ${analysis.reason} (${analysis.confidence}% confidence)`
    });
  }

  if (!analysis) {
    return null;
  }

  // Don't trade if signal is too weak (but analysis was saved above for UI)
  if (analysis.isWeak) {
    logger.info('Signal too weak for trading', {
      symbol,
      direction: analysis.direction,
      confidence: analysis.confidence,
      conditionsMet: analysis.metrics.conditionsMet,
      minConfidence: strategyConfig.minConfidence,
      minConditions: strategyConfig.minConditions,
      reason: analysis.reason
    });
    return null;
  }

  // Calculate trade amount based on risk level
  const tradeAmount = (userBalance * BigInt(riskLevelBps)) / 10000n;

  if (tradeAmount === 0n) {
    return null;
  }

  // Calculate minAmountOut with 1% slippage
  const minAmountOut = (tradeAmount * 99n) / 100n;

  return {
    direction: analysis.direction,
    confidence: analysis.confidence,
    tokenAddress,
    tokenSymbol,
    suggestedAmount: tradeAmount,
    minAmountOut,
    reason: analysis.reason,
    takeProfitPercent: analysis.suggestedTP,
    trailingStopPercent: analysis.suggestedSL,
    profitLockPercent: strategyConfig.profitLockPercent
  };
}

// ============================================================================
// MULTI-TIMEFRAME ANALYSIS (NEW UNIFIED SIGNAL ENGINE)
// ============================================================================

/**
 * Get Binance symbol from chain/token
 */
function getSymbolForToken(chainId: number, tokenAddress: string): string | null {
  return TOKEN_SYMBOLS[chainId]?.[tokenAddress] || null;
}

/**
 * Multi-Timeframe analysis by Binance symbol (Hyperliquid bot scans all HL perps this way).
 */
export async function analyzeMarketMTFBySymbol(
  symbol: string,
  strategy: TradingStrategy = 'normal'
): Promise<MarketAnalysis | null> {
  try {
    const timeframes: Timeframe[] = ['1m', '5m', '15m', '1h'];
    const rawSignal = await signalEngine.generateSignal(symbol, timeframes);
    const boosted = applyAggressiveTfBoost(rawSignal, strategy);
    const signal = { ...rawSignal, direction: boosted.direction, confidence: boosted.confidence };

    if (!signal || signal.confidence === 0) {
      return null;
    }

    const strategyConfig = STRATEGY_CONFIGS[strategy];
    const indicators: string[] = [];

    for (const pattern of signal.patterns.slice(0, 3)) {
      indicators.push(pattern.type.replace(/_/g, ' '));
    }

    for (const tf of signal.timeframes) {
      if (tf.confidence > 60) {
        indicators.push(`${tf.timeframe}: ${tf.direction}`);
      }
    }

    const now = new Date();
    const dayOfWeek = now.getDay();
    const hour = now.getUTCHours();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const isSunday = dayOfWeek === 0;
    const isMonday = dayOfWeek === 1;

    let weekendAlertLevel: 'none' | 'yellow' | 'red' = 'none';
    let marketWarning: string | undefined;

    if (isSunday && hour >= 18) {
      weekendAlertLevel = 'red';
      marketWarning = 'RED ALERT: Sunday evening - high volatility expected';
    } else if (isMonday && hour < 12) {
      weekendAlertLevel = 'red';
      marketWarning = 'RED ALERT: Monday morning - institutional activity';
    } else if (isMonday) {
      weekendAlertLevel = 'yellow';
      marketWarning = 'Caution: Monday market instability';
    } else if (isSunday || dayOfWeek === 6) {
      weekendAlertLevel = 'yellow';
      marketWarning = 'Weekend trading: Lower liquidity';
    }

    const tf1h = signal.timeframes.find((t) => t.timeframe === '1h');
    const tf15m = signal.timeframes.find((t) => t.timeframe === '15m');
    const rsi = tf15m?.rsi || 50;
    const macdSignal = tf15m?.macdSignal || 'neutral';
    const trend = tf1h?.trend || tf15m?.trend || 'SIDEWAYS';

    let finalDirection: 'LONG' | 'SHORT' = signal.direction as 'LONG' | 'SHORT';
    if (signal.direction === 'HOLD') {
      const higherTFs = signal.timeframes.filter((tf) => tf.timeframe !== '1m');
      const longVotes = higherTFs.filter((tf) => tf.direction === 'LONG').length;
      const shortVotes = higherTFs.filter((tf) => tf.direction === 'SHORT').length;
      const isBullishTrend = trend === 'UP' || trend.includes('UPTREND');
      const isBearishTrend = trend === 'DOWN' || trend.includes('DOWNTREND');

      if (isBullishTrend) finalDirection = 'LONG';
      else if (isBearishTrend) finalDirection = 'SHORT';
      else finalDirection = longVotes >= shortVotes ? 'LONG' : 'SHORT';
    }

    const directionalTfCount = signal.timeframes.filter(
      (tf) => tf.direction === finalDirection
    ).length;
    const counterTrend =
      (finalDirection === 'LONG' && trend === 'DOWN') ||
      (finalDirection === 'SHORT' && trend === 'UP');
    const trendAligned =
      directionalTfCount >= 3 &&
      signal.trendAlignment >= 75 &&
      !counterTrend;

    const isWeak =
      !trendAligned ||
      (strategyConfig.minConfidence >= 40
        ? signal.confidence < strategyConfig.minConfidence ||
          (signal.warnings.length > 0 && signal.trendAlignment < 50)
        : signal.confidence < strategyConfig.minConfidence);

    const reason =
      signal.reasons.length > 0
        ? signal.reasons.slice(0, 2).join(' | ')
        : `MTF: ${finalDirection} (${signal.confidence.toFixed(0)}%)`;

    let suggestedTP =
      signal.suggestedTP > 0
        ? ((signal.suggestedTP - signal.suggestedEntry) / signal.suggestedEntry) * 100
        : 5.0;
    let suggestedSL =
      signal.suggestedSL > 0
        ? ((signal.suggestedEntry - signal.suggestedSL) / signal.suggestedEntry) * 100
        : 1.5;

    suggestedTP = Math.min(Math.max(suggestedTP, 1.5), 10);
    suggestedSL = Math.min(Math.max(suggestedSL, 0.5), 3);

    if (isSunday || dayOfWeek === 6) {
      suggestedTP = Math.min(suggestedTP, 3.5);
      suggestedSL = Math.min(suggestedSL, 0.8);
    }

    const isOverheated = rsi > 75 || rsi < 25;
    const scalpingRecommended = isOverheated || signal.trendAlignment < 40;
    const patternBonus = signal.patterns.length > 0 ? Math.min(signal.patterns.length, 3) : 0;
    const signalStrength = Math.min(10, Math.round(signal.confidence / 10 + patternBonus));

    return {
      direction: finalDirection,
      confidence: Math.round(signal.confidence),
      strength: signalStrength,
      reason,
      indicators: indicators.slice(0, 5),
      isReversalSignal: signal.patternStrength > 50,
      suggestedTP,
      suggestedSL,
      isOverheated,
      isWeekendWarning: weekendAlertLevel !== 'none',
      weekendAlertLevel,
      scalpingRecommended,
      marketWarning,
      isWeak,
      metrics: {
        rsi: Math.round(rsi),
        macd: macdSignal,
        priceChange1h: '0.00',
        volumeRatio: '1.0',
        conditionsMet: Math.round(signal.trendAlignment / 20),
        trendAlignment: Math.round(signal.trendAlignment),
        directionalTfCount,
        h1Trend: trend,
        riskReward: (suggestedTP / suggestedSL).toFixed(2),
        trend:
          trend === 'UP' ? 'STRONG_UPTREND' : trend === 'DOWN' ? 'STRONG_DOWNTREND' : 'NEUTRAL',
        dayOfWeek: dayNames[dayOfWeek],
      },
    };
  } catch (err: unknown) {
    logger.debug('MTF analysis skipped (no OHLCV)', {
      symbol,
      error: err instanceof Error ? err.message : String(err),
    });
    return null;
  }
}

/**
 * NEW: Analyze market using Multi-Timeframe Signal Engine
 * This combines 1m, 5m, 15m, 1h data for a unified signal
 */
export async function analyzeMarketMTF(
  chainId: number,
  tokenAddress: string,
  strategy: TradingStrategy = 'normal'
): Promise<MarketAnalysis | null> {
  const symbol = getSymbolForToken(chainId, tokenAddress);
  if (!symbol) {
    logger.warn('Unknown token for MTF analysis', { chainId, tokenAddress });
    return null;
  }

  const mtf = await analyzeMarketMTFBySymbol(symbol, strategy);
  if (mtf) return mtf;
  return analyzeMarket(chainId, tokenAddress, strategy);
}

/**
 * Generate trade signal using Multi-Timeframe analysis (Binance symbol — HL perps).
 */
export async function generateTradeSignalMTFBySymbol(
  symbol: string,
  userBalance: bigint,
  riskLevelBps: number = 500,
  strategy: TradingStrategy = 'normal'
): Promise<TradeSignal | null> {
  const strategyConfig = STRATEGY_CONFIGS[strategy];
  const analysis = await analyzeMarketMTFBySymbol(symbol, strategy);
  const tokenSymbol = symbol.replace('USDT', '');

  if (!analysis || analysis.isWeak) {
    return null;
  }

  const tradeAmount = (userBalance * BigInt(riskLevelBps)) / 10000n;
  if (tradeAmount === 0n) return null;

  const minAmountOut = (tradeAmount * 99n) / 100n;
  const tokenAddress = `0x${'0'.repeat(40)}` as `0x${string}`;

  return {
    direction: analysis.direction,
    confidence: analysis.confidence,
    tokenAddress,
    tokenSymbol,
    suggestedAmount: tradeAmount,
    minAmountOut,
    reason: analysis.reason,
    takeProfitPercent: analysis.suggestedTP,
    trailingStopPercent: analysis.suggestedSL,
    profitLockPercent: strategyConfig.profitLockPercent,
  };
}

/**
 * Generate trade signal using Multi-Timeframe analysis
 */
export async function generateTradeSignalMTF(
  chainId: number,
  tokenAddress: string,
  userBalance: bigint,
  riskLevelBps: number = 500,
  strategy: TradingStrategy = 'normal'
): Promise<TradeSignal | null> {
  const strategyConfig = STRATEGY_CONFIGS[strategy];

  // Try MTF analysis first, fall back to single-timeframe
  const analysis = await analyzeMarketMTF(chainId, tokenAddress, strategy);

  const symbol = TOKEN_SYMBOLS[chainId]?.[tokenAddress] || 'UNKNOWN';
  const tokenSymbol = symbol.replace('USDT', '');

  // Save analysis to Supabase for UI display
  if (analysis) {
    await positionService.saveAnalysis({
      chainId,
      tokenAddress,
      tokenSymbol,
      signal: analysis.direction,
      confidence: analysis.confidence,
      currentPrice: 0,
      factors: {
        rsi: analysis.metrics.rsi,
        macdSignal: analysis.metrics.macd,
        volumeSpike: parseFloat(analysis.metrics.volumeRatio) > 1.5,
        trend: analysis.metrics.trend,
        pattern: analysis.indicators[0] || null,
        priceChange24h: parseFloat(analysis.metrics.priceChange1h) || 0
      },
      recommendation: `MTF ${analysis.direction} - ${analysis.reason} (${analysis.confidence}% confidence)`
    });
  }

  if (!analysis) {
    return null;
  }

  // Don't trade if signal is too weak
  if (analysis.isWeak) {
    logger.info('MTF Signal too weak for trading', {
      symbol,
      direction: analysis.direction,
      confidence: analysis.confidence,
      reason: analysis.reason
    });
    return null;
  }

  // Calculate trade amount based on risk level
  const tradeAmount = (userBalance * BigInt(riskLevelBps)) / 10000n;

  if (tradeAmount === 0n) {
    return null;
  }

  // Calculate minAmountOut with 1% slippage
  const minAmountOut = (tradeAmount * 99n) / 100n;

  return {
    direction: analysis.direction,
    confidence: analysis.confidence,
    tokenAddress,
    tokenSymbol,
    suggestedAmount: tradeAmount,
    minAmountOut,
    reason: analysis.reason,
    takeProfitPercent: analysis.suggestedTP,
    trailingStopPercent: analysis.suggestedSL,
    profitLockPercent: strategyConfig.profitLockPercent
  };
}

export class MarketService {
  private analysisCache: Map<string, { analysis: MarketAnalysis; timestamp: number }> = new Map();
  private cacheTTL = 30000; // 30 seconds
  private useMTF = true; // Use Multi-Timeframe analysis by default

  /**
   * Enable/disable Multi-Timeframe analysis
   */
  setMTFMode(enabled: boolean) {
    this.useMTF = enabled;
    logger.info(`MTF Analysis mode: ${enabled ? 'ENABLED' : 'DISABLED'}`);
  }

  /**
   * Get market analysis with caching (uses MTF by default)
   */
  async getAnalysis(chainId: number, tokenAddress: string, strategy: TradingStrategy = 'normal'): Promise<MarketAnalysis | null> {
    const cacheKey = `${chainId}-${tokenAddress}-${strategy}-${this.useMTF ? 'mtf' : 'single'}`;
    const cached = this.analysisCache.get(cacheKey);

    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.analysis;
    }

    // Use MTF analysis by default
    const analysis = this.useMTF
      ? await analyzeMarketMTF(chainId, tokenAddress, strategy)
      : await analyzeMarket(chainId, tokenAddress, strategy);

    if (analysis) {
      this.analysisCache.set(cacheKey, { analysis, timestamp: Date.now() });
    }

    return analysis;
  }

  /**
   * Generate signal with strategy support (uses MTF by default)
   */
  async getSignal(
    chainId: number,
    tokenAddress: string,
    userBalance: bigint,
    riskLevelBps: number = 500,
    strategy: TradingStrategy = 'normal'
  ): Promise<TradeSignal | null> {
    return this.useMTF
      ? generateTradeSignalMTF(chainId, tokenAddress, userBalance, riskLevelBps, strategy)
      : generateTradeSignal(chainId, tokenAddress, userBalance, riskLevelBps, strategy);
  }

  /** HL: scan any perp via Binance OHLCV symbol (e.g. SOLUSDT). */
  async getSignalForSymbol(
    symbol: string,
    userBalance: bigint,
    riskLevelBps: number = 500,
    strategy: TradingStrategy = 'normal'
  ): Promise<TradeSignal | null> {
    return this.useMTF
      ? generateTradeSignalMTFBySymbol(symbol, userBalance, riskLevelBps, strategy)
      : null;
  }

  /**
   * Get raw unified signal from SignalEngine (for API/frontend)
   */
  async getUnifiedSignal(symbol: string, timeframes: Timeframe[] = ['1m', '5m', '15m', '1h']): Promise<UnifiedSignal> {
    return signalEngine.generateSignal(symbol, timeframes);
  }
}

export const marketService = new MarketService();

// Re-export signalEngine for direct use
export { signalEngine } from './signalEngine';
